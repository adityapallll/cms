
Dripicons V2 has been created by Amit Jakhu from www.amitjakhu.com

Terms of Use:

Dripicons V2 is available for free for use in both personal and commercial projects. Dripicons 2.0 are licensed under Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by-sa/4.0/) and the font under SIL Open Font License (http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL).

You may freely use this icon set without restriction, in software programs, web templates and other materials intended for sale or distribution. No attribution or backlinks are required, but any form of spreading the word is always appreciated!
